#include "header.h"
LIB*Take_Book(LIB*head)
{
        LIB*temp=head;
        char ch,y=y;
        char author[40],book[20];
        printf("ENter the Bookname\n");
        __fpurge(stdin);
        scanf("%s",book);
        printf("ENter the Authorname\n");
        __fpurge(stdin);
        scanf("%s",author);
        if(head==NULL)
        {
                printf("Library is empty\n");
        }
        else if(head->next==NULL)
        {
                if(strcmp(book,head->bookname)==0)
                {
                        if(strcmp(author,head->authorname)==0)
                        {
                                List_Books(head);
                                puts("\n Do You Wish To Take Book\n");
                                printf("YES : y\t No : N\n");
                                __fpurge(stdin);
                                scanf("%c",&ch);
                                if(ch=='y')
                                {
                                        head->count=(head->count)-1;
                                        printf("%s Book is taken from the library\n",head->bookname);
                                }

                                        printf("Thanks For Visiting\n");
                                        printf("Visit Again\n");
                        }
                        else
                        {
                                printf("Book Not Found\n");
                                printf("Chusindi Chalu ika Pooooo .......\n");
                        }
                }
                else
                {
                        printf("Book Not Found\n");
                        printf("Chusindi Chalu ika Pooooo .......\n");
                }
        }
        else
        {
                while(temp)
                {
                        if(strcmp(book,temp->bookname)==0)
                        {
                                if(strcmp(author,temp->authorname)==0)
                                {
                                        temp->count=(temp->count)-1;
                                        printf("%s Book has taken from library\n",temp->bookname);
                                        break;
                                }
                                else
                                {
                                        temp=temp->next;
                                }
                        }
                        else
                        {
                                temp=temp->next;
                        }
                }
                if(temp==NULL)
                {
                        printf("Book Not Found\n");
                        printf("Chusindi Chalu ika Pooooo .......\n");
                }
        }
        return head;
}

