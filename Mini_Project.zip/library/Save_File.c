#include "header.h"
void Save_File(LIB*head)
{
        FILE*fp;
        int size=sizeof(LIB)-sizeof(LIB*);
        fp=fopen("data.txt","w");
        while(head)
        {
                fwrite(head,size,1,fp);
                fputs("\n",fp);
                head=head->next;
        }
        fclose(fp);
}
