#include"header.h"
LIB*Sync_File(LIB*head)
{
        int size=sizeof(LIB)-sizeof(LIB*);
        LIB var,*node,*temp;
        FILE*fp;
        fp=fopen("data.txt","r");
        if(fp)
        {
                while(fread(&var,size,1,fp))
                {
                        node=calloc(1,sizeof(LIB));
                        strcpy(node->bookname,var.bookname);
                        strcpy(node->authorname,var.authorname);
                        node->pages=var.pages;
                        node->count=var.count;
                        if(head==NULL)
                        {
                                head=node;
                        }
                        else
                        {
                                temp=head;
                                while(temp->next)
                                {
                                        temp=temp->next;
                                }
                                temp->next=node;
                        }
                }
                fclose(fp);
        }
        return head;
}


