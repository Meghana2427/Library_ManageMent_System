#include"header.h"
LIB* Add_New_Book(LIB*head)
{
        LIB*v;
        LIB*temp=head;
        LIB*node=calloc(1,sizeof(LIB));
        printf("Enter Bookname\n");
        __fpurge(stdin);
        scanf("%s",node->bookname);
        printf("Enter Author Name\n");
        __fpurge(stdin);
        scanf("%s",node->authorname);
        printf("Enter no of Pages\n");
        __fpurge(stdin);
        scanf("%llu",&node->pages);
        if(head==NULL)
        {
                head=node;
                head->count++;
        }
        else if(head->next==NULL)
        {
                if(strcmp(head->bookname,node->bookname)==0)
                {
                        if(strcmp(head->authorname,node->authorname)==0)
                        {
                                if(head->pages==node->pages)
                                {
                                        head->count++;
                                        return head;
                                }
                                else
                                {
                                        head->next=node;
                                        head->next->count++;
                                }
                        }
                        else
                        {
                                head->next=node;
                                head->next->count++;
                        }
                }
                else
                {
                        head->next=node;
                        head->next->count++;
                }
        }
	else
        {
                do
                {
                         if(strcmp(temp->bookname,node->bookname)==0)
                        {
                                if(strcmp(temp->authorname,node->authorname)==0)
                                {
                                        if(temp->pages==node->pages)
                                        {
                                                temp->count++;
                                                 return head;
                                        }
                                        else
                                        {
                                                temp=temp->next;
                                         }
                                }
                                else
                                {
                                        temp=temp->next;
                                 }
                        }
                        else
                        {
                                temp=temp->next;
                        }

                }while(temp->next);
                if(temp)
                {
                        if(strcmp(temp->bookname,node->bookname)==0)
                        {
                                if(strcmp(temp->authorname,node->authorname)==0)
                                {
                                        if(temp->pages==node->pages)
                                        {
                                                temp->count++;
                                                free(node);
                                                node=NULL;
                                                return head;
                                        }
                                        else
                                        {
                                           temp->next=node;
                                           temp->next->count++;

                                        }
                                }
                                else
                                {
                                           temp->next=node;
                                           temp->next->count++;
                                }
                        }
                        else
                        {
                               temp->next=node;
                               temp->next->count++;
                        }
        }
}
return head;
}

