                                      LIBRARY MANAGEMENT

1) Created an header file with .h extension and included  the required header files in it.
   In that file created an structure and gave aliasname (tydefined it).

2) Next created an menu.c file to display the menu/options to the user.Here in this file
   used switch case for choice to choose the required option to the enduser .For this used 
   switch case to choose the option and used while loop for it's iteration.

3) Next step in this created Add_Book.c file to add new books or to increase the count of 
   existing book.

4) Next created List_Books.c to display or to list the available books in library with book
   name and author name.

5)In this step created One Count_Books.c to Count the no of books based on author name and bookname choosen by user.

6) Then created Find_Book.c  to find the book based on book name and author name  entered by
   user

7)Now I've written one Sort_Book.c file to Sort the books that are available in Library.In this  I've used one Count_
