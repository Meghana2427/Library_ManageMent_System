#include"header.h"
LIB*Sort_Book(LIB*head)
{
        LIB*temp=head,*prev;
        LIB*t1;
        int cnt;
        cnt=Count_Nodes(head);
        if(head==NULL)
        {
                printf("Library is Empty\n");
        }
        else if(head->next==NULL)
        {
                printf("Only one Book In Library No Sorting Required\n");
        }
        else
        {
                temp=prev=head;
                for(int i=0;i<cnt;i++)
                {
                        temp=head;
                        for(int j=0;j<cnt-i-1;j++)
                        {
                                if(strcmp(temp->authorname,temp->next->authorname)>0)
                                {
                                        t1=calloc(1,sizeof(LIB));
                                        strcpy(t1->bookname,temp->bookname);
                                        strcpy(t1->authorname,temp->authorname);
                                        t1->pages=temp->pages;
                                        t1->count=temp->count;
                                        strcpy(temp->bookname,temp->next->bookname);
                                        strcpy(temp->authorname,temp->next->authorname);
                                        temp->pages=temp->next->pages;
                                        temp->count=temp->next->count;
                                        strcpy(temp->next->bookname,t1->bookname);
                                        strcpy(temp->next->authorname,t1->authorname);
                                        temp->next->pages=t1->pages;
                                        temp->next->count=t1->count;

                                        free(t1);
                                        t1=NULL;
                                }
                                temp=temp->next;
                        }
                        }
                }
                        return head;
        }

