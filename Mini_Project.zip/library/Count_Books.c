#include"header.h"
void Count_Specific_Book(LIB*head)
{
        LIB*temp=head;
        char temp1[20],temp2[40];
        printf("Enter the Book name\n");
        __fpurge(stdin);
        scanf("%s",temp1);
        printf("Enter the Author name\n");
        __fpurge(stdin);
        scanf("%s",temp2);
        if(head==NULL)
        {
                printf("No Book in Library\n");
        }
        else if(head->next==NULL)
        {
                if(strcmp(temp1,head->bookname)==0)
                {
                        if(strcmp(temp2,head->authorname)==0)
                        {
                                printf("count = %d",head->count);
                        }
                }
                else
                {
                        printf("The Book You Entered is not in Our Library\n");
                }
        }
        else
        {
                while(temp)
                {
                        if(strcmp(temp1,temp->bookname)==0)
                        {
                                if(strcmp(temp2,temp->authorname)==0)
                                {
                                        printf("Count = %d",temp->count);
                                        break;
                                }
                        }
                        temp=temp->next;
                }
                if(temp==NULL)
                {
                        printf("The Book You Entered is not in Our Library\n");
                }
        }
}

