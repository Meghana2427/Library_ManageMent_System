#include"header.h"
void Find_Book(LIB*head)
{
        LIB*temp=head;
        char temp1[20],temp2[40];
        printf("Enter the Book name\n");
        __fpurge(stdin);
        scanf("%s",temp1);
        printf("Enter the Author name\n");
        __fpurge(stdin);
        scanf("%s",temp2);
        if(head==NULL)
        {
                printf("No Book in Library\n");
        }
        else if(head->next==NULL)
        {
                if(strcmp(head->bookname,temp1)==0)
                {
                        if(strcmp(head->authorname,temp2)==0)
                        {
                           printf("%s %s %llu\n",head->bookname,head->authorname,head->pages);
                        }
                        else
                        {
                            printf("Entered Book Is Not In Library\n");
                        }
                }
                else
                {
                        printf("Entered Book Is Not In Library\n");
                }
        }
        else
        {
                while(temp)
                {
                        if(strcmp(temp->bookname,temp1)==0)
                        {
                           if(strcmp(temp->authorname,temp2)==0)
                           {
                                 printf("%s %s %llu\n",temp->bookname,temp->authorname,temp->pages);
                                break;
                           }
                        }
                        temp=temp->next;
                }
                if(temp==NULL)
                {
                        printf("Entered Book Is Not In Library\n");
                }
                else
                {
                        do
                        {
                                temp=temp->next;
                                if(strcmp(temp->bookname,temp1)==0)
                                {
                                        if(strcmp(temp->authorname,temp2)==0)
                                        {
                                                 printf("%s %s %llu\n",temp->bookname,temp->authorname,temp->pages);
                                        }
                                }
                        }while(temp->next);
                }
        }

}

