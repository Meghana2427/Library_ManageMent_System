#include<stdio.h>
#include<stdio_ext.h>
#include<string.h>
#include<stdlib.h>
//extern int cnt=0;
typedef struct st
{
        char bookname[20];
        char authorname[40];
        unsigned long long int pages;
        int count;
        struct st*next;
}LIB;
//extern int cnt;
extern LIB *v;
LIB*Add_New_Book(LIB*);
LIB* List_Books(LIB*);
void Count_Specific_Book(LIB*);
void Find_Book(LIB*);
LIB*Sort_Book(LIB*);
int Count_Nodes(LIB*);
LIB*Take_Book(LIB*head);
LIB*Sync_File(LIB*head);
void Save_File(LIB*head);
