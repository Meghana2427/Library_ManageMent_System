#include"header.h"
int Count_Nodes(LIB*head)
{
        int cnt=0;
        LIB*temp=head;
        if(head==NULL)
        {
                return 0;
        }
        else if(head->next==NULL)
        {
                return 1;
        }
        else
        {
        while(temp)
        {
                cnt++;
                temp=temp->next;
        }

        }
        printf("cnt=%d\n",cnt);
        return cnt;


}

