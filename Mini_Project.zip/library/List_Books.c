#include "header.h"
//extern int cnt;
LIB* List_Books(LIB*head)
//void List_Books(LIB*head)
{
        LIB*temp=head,*prev=head;
        if(head==NULL)
        {
                printf("There is No Books In Library\n");
                return head;
        }
        else if(head->next==NULL)
        {
                if(head->count!=0)
                {
                //      printf("cnt =%d ",cnt);
                //      cnt++;
                        printf("%s %s %llu %d",head->bookname,head->authorname,head->pages,head->count);
                }
                else
                {
                        //cnt--;
                        //printf("cnt = %d\n",cnt);
                        free(head);
                        head=NULL;
                }
        }
        else
        {
        //      do
                while(temp)
                {
                        if(head->count==0)
                        {
                                temp=head->next;
                                head=head->next;
                                free(prev);
                                prev=NULL;
                        }
                        if(temp->count!=0)
                        {
                                printf("\n");
                //      cnt++;
                        printf("%s %s %llu %d\n",temp->bookname,temp->authorname,temp->pages,temp->count);
                        printf("\n");
                        prev=temp;
                        temp=temp->next;
                        }
                        else
                        {
                        //      cnt--;
                        //      printf("cnt = %d\n",cnt);
                                prev->next=temp->next;
                                free(temp);
                                temp=NULL;
                        }
                }
        }
        return head;
}

