#include"header.h"
//int cnt=0;
int main()
{
        LIB *head=NULL;
        char choice;
        while(1)
        {
                printf("\n..................MENU....................\n");
                printf("\n Enter Choice\n");
                printf(" a/A : Add_New_Book\n l/L : list Books in Library\n c/C : Display count of Specific book\n t/T : Take Book From Library\n s/S : sort Books Based on Book Name and Author Name\n f/F : Find Book Base On Book Name and  Author Name\n v   : To sync \n V   : To Save Books info into file\n q/Q : Quit\n");
                __fpurge(stdin);
                scanf("%c",&choice);
                switch(choice)
                {
                        case 'a' :
                        case 'A' : head=Add_New_Book(head);
                                   break;
                        case 'l' :
                        case 'L' : head=List_Books(head);
                                   break;
                        case 'c' :
                        case 'C' : Count_Specific_Book(head);
                                   break;
                        case 'f' :
                        case 'F' : Find_Book(head);
                                   break;
                        case 's' :
                        case 'S' : head=Sort_Book(head);
                                   break;
                        case 't' :
                        case 'T' : head=Take_Book(head);
                                   break;
                        case 'v' : head=Sync_File(head);
                                   break;
                        case 'V' : Save_File(head);
                                   break;
                        case 'q' :
                        case 'Q' : exit(0);
                                   break;


                }
        }
}


